export const environment = {
  production: true,
  apiKey: 'AIzaSyBskDB1gDRrRzff3wYQ8eTLLYot6zdM5xU'
};
